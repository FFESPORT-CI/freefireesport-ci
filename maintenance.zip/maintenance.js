// =============================================
//   FF ESPORT-CI — SYSTÈME DE MAINTENANCE
//   Pour activer : MAINTENANCE_MODE = true
//   Pour désactiver : MAINTENANCE_MODE = false
// =============================================

const MAINTENANCE_MODE = false; // 👈 CHANGE ICI : true = maintenance ON / false = site normal

// Date et heure de retour prévue (format: "YYYY-MM-DDTHH:MM:SS")
const MAINTENANCE_END = "2026-05-10T20:00:00";

// Message personnalisé affiché sous le titre
const MAINTENANCE_MESSAGE = "Nous effectuons une mise à jour importante de la plateforme. Revenez très bientôt, soldats ! 🔥";

// =============================================
//   NE PAS MODIFIER EN DESSOUS
// =============================================

(function () {
    if (!MAINTENANCE_MODE) return; // Site normal, on ne fait rien

    // Injecte le CSS de maintenance
    const style = document.createElement('style');
    style.textContent = `
        #maintenance-screen {
            position: fixed;
            inset: 0;
            background: #050810;
            z-index: 99999;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
            font-family: 'Rajdhani', sans-serif;
            overflow: hidden;
        }

        .maint-grid-bg {
            position: fixed;
            inset: 0;
            background-image:
                linear-gradient(rgba(0,212,255,0.04) 1px, transparent 1px),
                linear-gradient(90deg, rgba(0,212,255,0.04) 1px, transparent 1px);
            background-size: 50px 50px;
            pointer-events: none;
        }

        .maint-scanlines {
            position: fixed;
            inset: 0;
            background: repeating-linear-gradient(
                0deg, transparent, transparent 2px,
                rgba(0,0,0,0.04) 2px, rgba(0,0,0,0.04) 4px
            );
            pointer-events: none;
        }

        .maint-corner { position: fixed; width: 40px; height: 40px; }
        .maint-corner.tl { top: 20px; left: 20px; border-top: 2px solid #00d4ff; border-left: 2px solid #00d4ff; }
        .maint-corner.tr { top: 20px; right: 20px; border-top: 2px solid #00d4ff; border-right: 2px solid #00d4ff; }
        .maint-corner.bl { bottom: 20px; left: 20px; border-bottom: 2px solid #00d4ff; border-left: 2px solid #00d4ff; }
        .maint-corner.br { bottom: 20px; right: 20px; border-bottom: 2px solid #00d4ff; border-right: 2px solid #00d4ff; }

        .maint-inner {
            position: relative;
            z-index: 2;
            text-align: center;
            max-width: 680px;
            width: 100%;
        }

        .maint-logo {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 2px solid #00d4ff;
            box-shadow: 0 0 30px rgba(0,212,255,0.4);
            margin: 0 auto 24px;
            display: block;
            animation: maint-pulse 2.5s ease-in-out infinite;
        }

        @keyframes maint-pulse {
            0%, 100% { box-shadow: 0 0 20px rgba(0,212,255,0.3); }
            50% { box-shadow: 0 0 50px rgba(0,212,255,0.6); }
        }

        .maint-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 6px 18px;
            border: 1px solid #00d4ff;
            background: rgba(0,212,255,0.1);
            border-radius: 2px;
            font-family: 'Share Tech Mono', monospace;
            font-size: 11px;
            color: #00d4ff;
            letter-spacing: 3px;
            text-transform: uppercase;
            margin-bottom: 24px;
        }

        .maint-dot {
            width: 6px; height: 6px;
            border-radius: 50%;
            background: #ff6b00;
            animation: maint-blink 1.2s ease-in-out infinite;
        }

        @keyframes maint-blink {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.1; }
        }

        .maint-title {
            font-family: 'Teko', sans-serif;
            font-size: clamp(40px, 8vw, 72px);
            font-weight: 700;
            color: white;
            letter-spacing: 4px;
            line-height: 1;
            margin-bottom: 8px;
            text-transform: uppercase;
        }

        .maint-title span { color: #00d4ff; }

        .maint-subtitle {
            font-family: 'Share Tech Mono', monospace;
            font-size: 12px;
            color: rgba(0,212,255,0.6);
            letter-spacing: 3px;
            margin-bottom: 20px;
        }

        .maint-message {
            font-size: 15px;
            color: #7a8aaa;
            line-height: 1.7;
            max-width: 480px;
            margin: 0 auto 40px;
        }

        /* Compte à rebours */
        .maint-countdown {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            flex-wrap: wrap;
            margin-bottom: 40px;
        }

        .countdown-block {
            display: flex;
            flex-direction: column;
            align-items: center;
            background: rgba(10,18,35,0.9);
            border: 1px solid rgba(0,212,255,0.2);
            border-radius: 6px;
            padding: 16px 20px;
            min-width: 80px;
            position: relative;
            overflow: hidden;
        }

        .countdown-block::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 1px;
            background: linear-gradient(90deg, transparent, #00d4ff, transparent);
        }

        .countdown-num {
            font-family: 'Teko', sans-serif;
            font-size: 48px;
            color: #00d4ff;
            line-height: 1;
            letter-spacing: 2px;
            text-shadow: 0 0 20px rgba(0,212,255,0.5);
        }

        .countdown-label {
            font-family: 'Share Tech Mono', monospace;
            font-size: 10px;
            color: #3a4a6a;
            letter-spacing: 2px;
            text-transform: uppercase;
            margin-top: 4px;
        }

        .countdown-sep {
            font-family: 'Teko', sans-serif;
            font-size: 40px;
            color: rgba(0,212,255,0.3);
            margin-bottom: 20px;
        }

        .maint-return {
            font-family: 'Share Tech Mono', monospace;
            font-size: 11px;
            color: #3a4a6a;
            letter-spacing: 2px;
            margin-bottom: 32px;
        }

        .maint-return span {
            color: #00d4ff;
        }

        /* Barre de progression fictive */
        .maint-progress-wrap {
            margin-bottom: 32px;
        }

        .maint-progress-label {
            display: flex;
            justify-content: space-between;
            font-family: 'Share Tech Mono', monospace;
            font-size: 10px;
            color: #3a4a6a;
            letter-spacing: 2px;
            margin-bottom: 8px;
        }

        .maint-progress-bar {
            height: 3px;
            background: rgba(255,255,255,0.06);
            border-radius: 3px;
            overflow: hidden;
        }

        .maint-progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #00d4ff, #0088aa);
            border-radius: 3px;
            box-shadow: 0 0 10px rgba(0,212,255,0.5);
            transition: width 1s ease;
        }

        /* Footer maintenance */
        .maint-footer {
            font-family: 'Share Tech Mono', monospace;
            font-size: 11px;
            color: #1a2a3a;
            letter-spacing: 2px;
        }

        .maint-footer a {
            color: rgba(0,212,255,0.4);
            text-decoration: none;
            transition: color 0.2s;
        }

        .maint-footer a:hover { color: #00d4ff; }

        /* Responsive */
        @media (max-width: 480px) {
            .countdown-block { min-width: 60px; padding: 12px 14px; }
            .countdown-num { font-size: 36px; }
            .maint-corner { width: 24px; height: 24px; }
        }
    `;
    document.head.appendChild(style);

    // Injecte le HTML de maintenance
    const screen = document.createElement('div');
    screen.id = 'maintenance-screen';

    const endDate = new Date(MAINTENANCE_END);
    const endFormatted = endDate.toLocaleDateString('fr-FR', {
        weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
    }) + ' à ' + endDate.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });

    screen.innerHTML = `
        <div class="maint-grid-bg"></div>
        <div class="maint-scanlines"></div>
        <div class="maint-corner tl"></div>
        <div class="maint-corner tr"></div>
        <div class="maint-corner bl"></div>
        <div class="maint-corner br"></div>

        <div class="maint-inner">
            <img src="ffesci.png" alt="FFESCI" class="maint-logo"
                onerror="this.style.display='none'">

            <div class="maint-badge">
                <span class="maint-dot"></span>
                SYSTÈME EN MAINTENANCE
            </div>

            <h1 class="maint-title">FF ESPORT<span>-CI</span></h1>
            <p class="maint-subtitle">// OPÉRATION DE MISE À JOUR EN COURS</p>

            <p class="maint-message">${MAINTENANCE_MESSAGE}</p>

            <div class="maint-countdown">
                <div class="countdown-block">
                    <span class="countdown-num" id="maint-jours">00</span>
                    <span class="countdown-label">JOURS</span>
                </div>
                <span class="countdown-sep">:</span>
                <div class="countdown-block">
                    <span class="countdown-num" id="maint-heures">00</span>
                    <span class="countdown-label">HEURES</span>
                </div>
                <span class="countdown-sep">:</span>
                <div class="countdown-block">
                    <span class="countdown-num" id="maint-minutes">00</span>
                    <span class="countdown-label">MINUTES</span>
                </div>
                <span class="countdown-sep">:</span>
                <div class="countdown-block">
                    <span class="countdown-num" id="maint-secondes">00</span>
                    <span class="countdown-label">SECONDES</span>
                </div>
            </div>

            <p class="maint-return">RETOUR PRÉVU : <span>${endFormatted.toUpperCase()}</span></p>

            <div class="maint-progress-wrap">
                <div class="maint-progress-label">
                    <span>// DÉPLOIEMENT</span>
                    <span id="maint-pct">0%</span>
                </div>
                <div class="maint-progress-bar">
                    <div class="maint-progress-fill" id="maint-fill" style="width:0%"></div>
                </div>
            </div>

            <div class="maint-footer">
                <p>© 2026 FF ESPORT-CI &nbsp;|&nbsp;
                <a href="https://wa.me/2250173661277" target="_blank">CONTACTER LE STAFF</a></p>
            </div>
        </div>
    `;

    document.body.appendChild(screen);

    // Compte à rebours
    function updateCountdown() {
        const now = new Date().getTime();
        const end = endDate.getTime();
        const diff = end - now;

        if (diff <= 0) {
            // Maintenance terminée automatiquement
            document.getElementById('maint-jours').textContent = '00';
            document.getElementById('maint-heures').textContent = '00';
            document.getElementById('maint-minutes').textContent = '00';
            document.getElementById('maint-secondes').textContent = '00';
            document.getElementById('maint-fill').style.width = '100%';
            document.getElementById('maint-pct').textContent = '100%';
            return;
        }

        const jours    = Math.floor(diff / (1000 * 60 * 60 * 24));
        const heures   = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes  = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const secondes = Math.floor((diff % (1000 * 60)) / 1000);

        const pad = n => String(n).padStart(2, '0');
        document.getElementById('maint-jours').textContent    = pad(jours);
        document.getElementById('maint-heures').textContent   = pad(heures);
        document.getElementById('maint-minutes').textContent  = pad(minutes);
        document.getElementById('maint-secondes').textContent = pad(secondes);

        // Barre de progression basée sur le temps écoulé
        // On suppose que la maintenance dure max 7 jours
        const dureeMax = 7 * 24 * 60 * 60 * 1000;
        const ecoule = dureeMax - diff;
        const pct = Math.min(Math.max(Math.floor((ecoule / dureeMax) * 100), 5), 95);
        document.getElementById('maint-fill').style.width = pct + '%';
        document.getElementById('maint-pct').textContent = pct + '%';
    }

    updateCountdown();
    setInterval(updateCountdown, 1000);

    // Bloque le scroll du body
    document.body.style.overflow = 'hidden';
})();
